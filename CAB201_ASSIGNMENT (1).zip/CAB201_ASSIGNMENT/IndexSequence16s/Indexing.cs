﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;




namespace DirecFileAccess
{

    class Indexing
    {
        /// <summary>
        /// The class indexing contains the function to create an indexed file of the 16S fasta with the byte sizes of each dna sequence to provide
        /// direct access for the question in level 4.
        /// </summary>
       

        static void Main(string[] args)
        {
            /// <summary>
            /// This function main takes the users input arguments and if they enter the correct files it will create an index file
            /// of that particular file for later use.
            /// </summary>
            /// <param name="args[]">This parameter is an array that contains all of the users inputs</param>
            /// <returns>This function returns void </returns>

            if (File.Exists(args[0]))
            {

            }

            else
            {
               
                Console.WriteLine("Please enter a valid filename");
                Environment.Exit(0);
            }


            string file1 = args[1];
            int counter = 0; // line counter in text file
            string line; // line of text
            int position = 0; // file position of first line
            List<int> pos = new List<int>(); // an array to keep ine positions in
            List<int> size = new List<int>(); // an array to keep ine size in
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string result = string.Empty;
            // Read the file and display it line by line.  
            System.IO.StreamReader file =
                new System.IO.StreamReader(args[0]);
            if (File.Exists(Path.Combine("../../../CAB201_ASSIGNMENT/bin/Debug/", file1)))
            {
                File.Delete(Path.Combine("../../../CAB201_ASSIGNMENT/bin/Debug/", file1));
            }
            using (StreamWriter outputFile = new StreamWriter("../../../CAB201_ASSIGNMENT/bin/Debug/"+file1, true))
            {
                while ((line = file.ReadLine()) != null)
                {
                    if (counter % 2 == 0)
                    {
                        pos.Add(position); // store line position
                        size.Add(line.Length + 1); // store line size
                        string[] words = line.Split(' ');

                        outputFile.WriteLine(words[0].Substring(1) + ' ' + (pos.Last())); // display the line
                    }
                        position = position + line.Length + 1; // add 1 for '\n' character in file
                        //string result1 = String.Concat(line[counter]);
                        

                        


                    
                    counter++;
                }
            }

        }


    }
}